# دمج ميزات حساب المطور

تم نقل ملفات واجهة حساب المطور ومركز المطور من نسخة site إلى clean، مع إبقاء `online-auth.js` و`supabase-config.js` و`supabase.sql` الأصليين في clean.

## ملفات تمت إضافتها أو دمجها
- `gx-features.js`
- `developer-account.js`
- `developer-console.js`
- تحديث `index.html`
- تحديث `settings.js` و`store-extras.js`

## مهم قبل اعتبار الميزة جاهزة على الإنتاج
الواجهة تعتمد على Supabase ومكوّن خادمي اسمه Edge Function `developer-code`، كما يعتمد مركز المطور على جداول وصلاحيات إضافية مثل `profiles`, `apps`, و`app_releases` وStorage. لم يتم نشر أي شيء إلى مشروع Supabase من خلال تعديل الملفات فقط. راجع إعدادات Supabase الحالية، وطبّق ترحيلات قاعدة البيانات/إعداد Edge Function المطلوبة قبل الاختبار الفعلي. لا تضع `service_role` أو أسرار الخادم في ملفات الواجهة.
